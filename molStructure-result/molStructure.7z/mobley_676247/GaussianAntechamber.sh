#!/bin/bash
echo "#-----------------------------------------------------------#"
# Reference: http://ambermd.org/tutorials/ForceField.php
echo "#-----------------------------------------------------------#"
 
echo "#-----------------------------------------------------------#"
echo "Step 1: prepare Gaussian input file .com"
echo "#-----------------------------------------------------------#"
antechamber -i mobley_676247.mol2 -fi mol2 -o mobley_676247.com -fo 		gcrt -pf y -gm "%mem=4096MB" -gn "%nproc=8" -nc 0 -gk 		"#HF/6-31G* SCF=tight Test Pop=MK iop(6/33=2) iop(6/42=6)"
 
echo "#-----------------------------------------------------------#"
echo "Step 2: run Gaussian jobs."
echo "#-----------------------------------------------------------#"
nohup g09 mobley_676247.com > mobley_676247.log &
wait 
 
echo "#-----------------------------------------------------------#"
echo "Step 3: fitting Energy landspace get the RESP charge."
echo "#-----------------------------------------------------------#"
antechamber -i mobley_676247.log -fi gout -o mobley_676247.mol2 -fo mol2 -c resp -rn TST 
 
echo "#-----------------------------------------------------------#"
echo "Step 4: Get the atom deficiency force field parameters."
echo "#-----------------------------------------------------------#"
parmchk2 -i mobley_676247.mol2 -f mol2 -o mobley_676247.frcmod 
 
echo "#-----------------------------------------------------------#"
echo "Step 5: Using tleap get amber input file .inpcrd and .prmtop."
echo "#-----------------------------------------------------------#"
tleap -f leap.in 
 
echo "#-----------------------------------------------------------#"
echo "Step 6: Using acpype.py get GROMACS topology and coordinate file."
echo "#-----------------------------------------------------------#"
python2 ../../acpype.py -p mobley_676247.prmtop -x mobley_676247.inpcrd -d
 
echo "#-----------------------------------------------------------#"
echo "Step 7: Using packmol get the packed coordinate."
echo "#-----------------------------------------------------------#"
packmol < *.inp
 
echo "#-----------------------------------------------------------#"
echo "Step 8: Adjust the .top file molecules number information."
echo "#-----------------------------------------------------------#"
sed -i "s/TST              1 /TST  437/g" TST_GMX.top

 
